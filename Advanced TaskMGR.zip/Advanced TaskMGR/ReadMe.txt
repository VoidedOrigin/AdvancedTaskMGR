                          !!Advanced Task Manager!!
                   This Tool Is A Tool Created By (VoidedOrigin)
 It Was Originally Created To Help Me Do A Investigation To See If Xeno Is Safe
                Which,, Talking About Xeno, Xeno Is Dangerous. Its NOT SAFE!
Uninstall If You Have It, This Tool Can Help YOU Detect Malware On Your Device!
Its Only For PC/Laptops, And This Tool Is Open Source, But I Recommend Running
AdvancedTaskMGR.exe Cuz Then You Dont Have To Install Py / The Library's For The
Python Scripts If You Dont Trust The The exe Heres The Library's You Need:
(pip install psutil watchdog) For My Version Of Python (Idk Which) Its
               (py -m pip install psutil watchdog)

Now, Uh Why Not Use Regular TaskMGR? Well.. This One Can See Hidden Processes
And Much More Beacuse You Can See Parents/Childs, Network Connections, Dlls,
StartUp Folders (Hidden), File Activity. So Yeah. Its Really Advanced TaskMGR.

                      Now Thats All I Have To Say! Yado.!!